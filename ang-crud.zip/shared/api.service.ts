import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CompanyModel } from '../Model/CompanyModel';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) {}

  apiURL = 'http://localhost:3000/company';

  getAllData(): Observable<CompanyModel[]> {
    return this.http.get<CompanyModel[]>(this.apiURL);
  }
  getDataByCode(id: any): Observable<CompanyModel[]> {
    return this.http.get<CompanyModel[]>(this.apiURL + '/' + id);
  }
  removeDataByCode(id: any): Observable<CompanyModel[]> {
    return this.http.delete<CompanyModel[]>(this.apiURL + '/' + id);
  }
  createData(companydata: any) {
    return this.http.post(this.apiURL, companydata);
  }
  updateData(id: any, userdata: any) {
    return this.http.put<CompanyModel[]>(this.apiURL + '/' + id, userdata);
  }
}
