import { Component, OnInit, ViewChild } from '@angular/core';
import { CompanyModel } from '../Model/CompanyModel';
import { MatDialog } from '@angular/material/dialog';
import { PopupComponent } from '../popup/popup.component';
import { ApiService } from '../shared/api.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css'],
})
export class CompanyComponent implements OnInit {
  constructor(private dialog: MatDialog, private as: ApiService) {}
  @ViewChild(MatPaginator) _paginator:MatPaginator
  companydata!: CompanyModel[];
  finalData:any

  ngOnInit(): void {
    this.loadData();
  }

  displayColums: string[] = [
    'id',
    'name',
    'empcount',
    'revenue',
    'address',
    'isactive',
    'action',
  ];

  OpenPopup(id: any) {
    const _popup = this.dialog.open(PopupComponent, {
      width: '500px',
      exitAnimationDuration: '1000ms',
      enterAnimationDuration: '1000ms',
      data: {
        id: id,
      },
    });
    _popup.afterClosed().subscribe((r) => {
      this.loadData();
    });
  }
  loadData() {
    this.as.getAllData().subscribe((res) => {
      this.companydata = res;
      this.finalData=new MatTableDataSource<CompanyModel>(this.companydata)
      this.finalData.paginator=this._paginator
    });
  }
  editData(id: any) {
    this.OpenPopup(id);
  }
  deleteData(id:any){
    this.as.removeDataByCode(id).subscribe(r=>{
      this.loadData()
    })
  }
}
