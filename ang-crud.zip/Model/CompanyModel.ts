

export interface CompanyModel{

  id:number,
  name:string,
  empcount:number,
  revenue:number,
  address:string,
  isactive: boolean
}
