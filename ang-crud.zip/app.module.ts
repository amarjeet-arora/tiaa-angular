import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PopupComponent } from './popup/popup.component';
import { CompanyComponent } from './company/company.component';
import { MaterialModule } from './MaterialModule';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'

@NgModule({
  declarations: [AppComponent, PopupComponent, CompanyComponent],
  imports: [BrowserModule, BrowserAnimationsModule,MaterialModule,FormsModule,ReactiveFormsModule,HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
